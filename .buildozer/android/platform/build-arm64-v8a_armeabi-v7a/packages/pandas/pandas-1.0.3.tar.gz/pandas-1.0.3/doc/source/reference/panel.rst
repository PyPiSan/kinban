{{ header }}

.. _api.panel:

=====
Panel
=====
.. currentmodule:: pandas

`Panel` was removed in 0.25.0. For prior documentation, see the `0.24 documentation <https://pandas.pydata.org/pandas-docs/version/0.24/reference/panel.html>`_
